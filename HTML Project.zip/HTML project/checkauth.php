<?php
$auth=array();
$myfile = fopen("record.txt", "r") or die("Unable to open file!");

while($line=fgets($myfile)){
	$line=trim($line);
	//echo $line."<br/>";
	$up=explode(" ",$line);
	//echo $up[0]." - ".$up[1]."<br/>";
	$auth[$up[0]]=$up[1];
	//$auth["raju"]="123";
}

foreach($auth as $k=>$v){
	if($_POST["un"]==$k && $_POST["pass"]==$v){
	header("Location: home.php");
	}
	else
	{
		echo "invalid user";
	}
}
?>